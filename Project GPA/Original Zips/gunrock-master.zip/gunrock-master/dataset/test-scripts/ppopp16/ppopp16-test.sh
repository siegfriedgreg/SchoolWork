sh bfs-test.sh && sh sssp-test.sh && sh bc-test.sh && sh pr-test.sh && sh cc-test.sh

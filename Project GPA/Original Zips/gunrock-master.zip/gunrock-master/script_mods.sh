#!/bin/bash

module load cuda/7.5
module load metis
module load boost/1.60.0
module load gcc/4.8.4

module list

exit
